from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

# Путь к проекту внутри Docker контейнера (см. volumes в docker-compose)
DBT_PROJECT_DIR = '/opt/airflow/dbt_project'

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    'dbt_customer_service_dag',
    default_args=default_args,
    description='A simple DAG to run dbt project for Customer Service Analytics',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    catchup=False,
    tags=['dbt', 'variant_13'],
) as dag:

    # Задача 1: Загрузка "сырых" данных (Seeds) из CSV в базу
    dbt_seed = BashOperator(
        task_id='dbt_seed',
        bash_command=f'cd {DBT_PROJECT_DIR} && dbt seed --profiles-dir .',
    )

    # Задача 2: Запуск моделей (трансформация данных)
    dbt_run = BashOperator(
        task_id='dbt_run',
        bash_command=f'cd {DBT_PROJECT_DIR} && dbt run --profiles-dir .',
    )

    # Задача 3: Тестирование данных (проверка constraints)
    dbt_test = BashOperator(
        task_id='dbt_test',
        bash_command=f'cd {DBT_PROJECT_DIR} && dbt test --profiles-dir .',
    )

    # Порядок выполнения
    dbt_seed >> dbt_run >> dbt_test
