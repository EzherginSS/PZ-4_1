with survey_data as (
    select * from {{ ref('stg_survey_data') }}
),

metrics_calculation as (

    select
        call_date,
        count(survey_id) as total_surveys,
        
        -- Расчет CSAT: % оценок 4 и 5
        (count(case when satisfaction_score >= 4 then 1 end)::float / count(*)) * 100 as csat_percent,
        
        -- Расчет Average CES
        avg(effort_score) as avg_ces_score,
        
        -- Расчет NPS (Упрощенно для примера)
        -- Промоутеры (оценка > 5, т.к. в данных макс 7), Детракторы (оценка < 4)
        (
            (count(case when recommendation_score >= 6 then 1 end)::float - 
             count(case when recommendation_score <= 4 then 1 end)::float) 
            / count(*)
        ) * 100 as nps_score

    from survey_data
    group by call_date

)

select * from metrics_calculation
order by call_date
