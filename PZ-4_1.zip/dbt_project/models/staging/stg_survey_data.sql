with source as (
    
    -- Читаем данные из CSV, загруженного через dbt seed
    select * from {{ ref('raw_survey_data') }}

),

renamed as (

    select
        "ID" as survey_id,
        "CallDate"::date as call_date,
        
        -- Предполагаем, что Q3 - это Satisfaction (CSAT) по шкале 1-5
        "Q3" as satisfaction_score,
        
        -- Предполагаем, что Q4 - это Customer Effort (CES) по шкале 1-5
        "Q4" as effort_score,
        
        -- Предполагаем, что Q8 - это Net Promoter Score (NPS) 
        -- В исходных данных значения странные (до 7), приведем к стандартной логике 
        -- для учебных целей берем как есть
        "Q8" as recommendation_score

    from source
    where "ID" is not null

)

select * from renamed
